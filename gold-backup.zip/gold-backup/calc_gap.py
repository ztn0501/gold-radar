#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
积存金·缺口测算（可复现）
==========================================================
用途：给定本金、成本、现价、期限、利率，算出各方案在五种情景下的
      「一年后缺口 = 应还本息 − 期末资产」。

背景结论：300 万 / 4800 成本 / 一年期限，金价须到 4944 才够还本息。
          历史上熊市 12 个月最大涨幅只有 +18%，到过 22% 的没有。

用法：
    python3 calc_gap.py                     # 用默认参数
    python3 calc_gap.py 3000000 4800 4053.29 0.03 12
                                            # 本金 成本 现价 年利率 月数
    python3 calc_gap.py --help

改方案：见文件底部 PLANS 字典，格式
    [(类型, 阈值, 比例), ...]
    类型 'now'=立即，'up'=价格≥阈值，'down'=价格≤阈值
"""
import sys

# ---------- 参数 ----------
FX = 6.696          # 人民币/美元
OZ = 31.1035        # 克/盎司
K = FX / OZ         # USD/oz → 元/克 的换算系数 = 0.21528

CAP    = 3_000_000.0   # 本金（元）
COST   = 4800.0        # 成本价（USD/oz）
CUR    = 4053.29       # 现价（USD/oz）
RATE   = 0.03          # 年利率
MONTHS = 12            # 期限（月）

# ---------- 情景 ----------
# 节点用「时间比例」0~1，实际月份 = 比例 × MONTHS，改期限自动缩放
SCEN = {
    "跌到3200": [(0.0, CUR), (0.5, 3900), (1.0, 3200)],
    "跌到3500": [(0.0, CUR), (0.5, 3800), (1.0, 3500)],
    "横在4050": [(0.0, CUR), (0.5, 4100), (1.0, 4050)],
    "反弹4400": [(0.0, CUR), (0.5, 4200), (1.0, 4400)],
    "涨到4950": [(0.0, CUR), (0.5, 4500), (1.0, 4950)],
}

# ---------- 接回档位 ----------
BUYS = [(3400, 0.34), (3200, 0.50), (3000, 1.00)]

# ---------- 方案 ----------
# 每项 = (卖出动作, 是否接回, 底仓比例)
# 注意：接回只对"部分卖出"的方案成立；清仓方案不接回，否则等于又满仓。
PLANS = {
    "A 死拿":          ([],                                        False, 1.00),
    "B 卖半50%":       ([('now', 0, 0.50)],                        True,  0.15),
    "C 三段40/30/15": ([('now', 0, 0.40), ('up', 4250, 0.30), ('down', 3850, 0.15)], True, 0.15),
    "D 卖30%":         ([('now', 0, 0.30)],                        True,  0.15),
    "E 清仓90%":       ([('now', 0, 0.90)],                        False, 0.10),
}


def path_of(pts, T=None):
    """把 (比例, 价格) 节点按 T 个月线性插值成逐月序列"""
    T = int(T or MONTHS)
    out = [None] * (T + 1)
    for j in range(len(pts) - 1):
        r0, p0 = pts[j]
        r1, p1 = pts[j + 1]
        m0, m1 = int(round(r0 * T)), int(round(r1 * T))
        if m1 <= m0:
            continue
        for m in range(m0, m1 + 1):
            out[m] = p0 + (p1 - p0) * (m - m0) / (m1 - m0)
    for m in range(T + 1):
        if out[m] is None:
            out[m] = pts[-1][1]
    return out


def run(path, sells, do_buy=True, keep=0.15):
    g0 = CAP / (COST * K)
    g, cash = g0, 0.0
    done = [False] * len(sells)
    bi = 0
    log = []
    for m, px in enumerate(path):
        for i, (typ, lv, fr) in enumerate(sells):
            if done[i]:
                continue
            hit = True if typ == 'now' else (px >= lv if typ == 'up' else px <= lv)
            if hit and g > g0 * keep + 0.01:
                q = min(g0 * fr, g - g0 * keep)
                if q > 0.01:
                    g -= q
                    cash += q * px * K
                    done[i] = True
                    log.append((m, fr, px))
        while do_buy and bi < len(BUYS) and px <= BUYS[bi][0] and cash > 1000:
            use = cash * BUYS[bi][1]
            g += use / (px * K)
            cash -= use
            bi += 1
    return g * path[-1] * K + cash, g, log


def main():
    global CAP, COST, CUR, RATE, MONTHS
    args = sys.argv[1:]
    if args and args[0] in ("-h", "--help"):
        print(__doc__)
        return
    if len(args) >= 5:
        CAP, COST, CUR, RATE = (float(x) for x in args[:4])
        MONTHS = int(float(args[4]))
    elif len(args) > 0:
        print("参数不足，需要 5 个：本金 成本 现价 年利率 月数")
        return

    g0 = CAP / (COST * K)
    pay = CAP * (1 + RATE * MONTHS / 12)
    need = pay / (g0 * K)

    print("=" * 88)
    print(f"本金 {CAP/1e4:.0f} 万｜成本 {COST:.0f} USD/oz（{COST*K:.1f} 元/克）"
          f"｜现价 {CUR:.2f}（{CUR*K:.1f} 元/克）")
    print(f"持仓 {g0:.1f} 克｜市值 {g0*CUR*K/1e4:.1f} 万｜浮亏 {(CUR/COST-1)*100:.2f}%")
    print(f"期限 {MONTHS} 个月｜应还本息 {pay/1e4:.1f} 万")
    print(f"要够还，金价须到 {need:.0f} USD/oz（需涨 {(need/CUR-1)*100:+.1f}%）")
    print("=" * 88)

    print(f"\n【缺口表】正数=不够还（万元）")
    print(f"  {'方案':<17}" + "".join(f"{k:>13}" for k in SCEN))
    rows = {}
    for nm, (sl, db, kp) in PLANS.items():
        line = []
        for k, pts in SCEN.items():
            v, g, _ = run(path_of(pts), sl, do_buy=db, keep=kp)
            line.append((pay - v) / 1e4)
            rows[(nm, k)] = (v, g)
        print(f"  {nm:<17}" + "".join(f"{x:>12.1f}" for x in line))

    print(f"\n【期末克数】")
    print(f"  {'方案':<17}" + "".join(f"{k:>13}" for k in SCEN))
    for nm, (sl, db, kp) in PLANS.items():
        print(f"  {nm:<17}" + "".join(f"{rows[(nm,k)][1]:>13.0f}" for k in SCEN))

    print(f"\n【C 方案逐笔】")
    for k, pts in SCEN.items():
        v, g, log = run(path_of(pts), PLANS["C 三段40/30/15"][0], do_buy=True, keep=0.15)
        acts = " + ".join(f"{int(f*100)}%@{p:.0f}" for m, f, p in log) or "无动作"
        print(f"  {k:<9} {acts:<40} 期末 {v/1e4:>6.1f}万 {g:>5.0f}克")

    print("\n" + "=" * 88)
    print("说明：现金不计息、不减点差；卖点按价格触发；部分卖出保留 15% 底仓，清仓方案不接回。")
    print("      改情景/方案请编辑文件顶部的 SCEN / PLANS / BUYS。")


if __name__ == "__main__":
    main()
